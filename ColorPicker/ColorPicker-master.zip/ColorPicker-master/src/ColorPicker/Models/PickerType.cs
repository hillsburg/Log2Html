﻿namespace ColorPicker.Models
{
    public enum PickerType : int
    {
        HSV = 0, HSL = 1
    }
}
