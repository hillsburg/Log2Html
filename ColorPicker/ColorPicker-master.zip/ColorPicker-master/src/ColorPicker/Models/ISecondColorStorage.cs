﻿namespace ColorPicker.Models
{
    interface ISecondColorStorage
    {
        ColorState SecondColorState { get; set; }
    }
}
